package org.example;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import static org.example.Main.takeScreenshot;

public class ScenarioTwo {
	WebDriver driver;
//Group-4
	@Test
	public void launch() throws IOException, InterruptedException {
		// Initialize the ChromeDriver
		driver = new ChromeDriver();
		driver.get("https://northeastern.instructure.com");
		driver.manage().window().maximize();

		// Get data from Excel file
		String excelFilePath = "/Users/jayakishnani/Desktop/data.xlsx";
		FileInputStream inputStream = new FileInputStream(excelFilePath);
		Workbook workbook = new XSSFWorkbook(inputStream);
		Sheet sheet = workbook.getSheet("Sheet1");
		String usernameEmail = sheet.getRow(0).getCell(0).getStringCellValue();
		String username = sheet.getRow(1).getCell(0).getStringCellValue();
		String password = sheet.getRow(0).getCell(1).getStringCellValue();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5000));
		// Enter user email id
		WebElement userEmail = driver.findElement(By.id("i0116"));
		userEmail.sendKeys(usernameEmail);

		// Click "Next"
		WebElement next = wait.until(ExpectedConditions.elementToBeClickable(By.id("idSIButton9")));

		next.click();
		Thread.sleep(1000);
        //Fill in password
		WebElement userPassword = driver.findElement(By.id("i0118"));
		userPassword.sendKeys(password);

		// Wait until the page is fully loaded
		Thread.sleep(2000);
		WebElement SignIn = wait.until(ExpectedConditions.elementToBeClickable(By.id("idSIButton9")));

		SignIn.click();
		//Click on yes this is my device
				WebElement yesThisIsMyDevice=wait.until(ExpectedConditions.elementToBeClickable(By.id("trust-browser-button")));
				yesThisIsMyDevice.click();
		// Wait until the manual DUO finish
		WebElement doNotShowAgain = wait.until(ExpectedConditions.elementToBeClickable(By.name("DontShowAgain")));
		doNotShowAgain.click();
		WebElement noButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("idBtn_Back")));
		noButton.click();

		// Perform Calendar actions
		WebElement calendar = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='global_nav_calendar_link']")));
		calendar.click();
		Thread.sleep(500);
		takeScreenshot(driver, "createElementBefore", "s2");
		for (int i = 1; i <= 2; i++) {
			Row r = sheet.getRow(i);
			String title = r.getCell(3).getStringCellValue();
			String date = r.getCell(4).getStringCellValue();
			String time = r.getCell(5).getNumericCellValue() + "";
			String Details = r.getCell(7).getStringCellValue();
			// Add action
			WebElement add = wait
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='create_new_event_link']")));
			add.click();

			// To-do action
			WebElement event1 = wait
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"edit_event_tabs\"]/ul/li[2]")));
			event1.click();

			Thread.sleep(2000);
			WebElement titleW = driver.findElement(By.id("planner_note_title"));
			WebElement dateW = driver.findElement(By.id("planner_note_date"));
			WebElement timeW = driver.findElement(By.id("planner_note_time"));
			WebElement detailW = driver.findElement(By.id("details_textarea"));
			titleW.sendKeys(title);
			dateW.clear();
			dateW.sendKeys(date);
			timeW.sendKeys(time);
			detailW.sendKeys(Details);

			Thread.sleep(500);
			takeScreenshot(driver, "createElementbeforeClick" + i, "s2");
			WebElement submit = driver
					.findElement(By.xpath("//*[@id=\"edit_planner_note_form_holder\"]/form/div[2]/button"));
			submit.click();

		}
		Thread.sleep(500);
		takeScreenshot(driver, "createElementAfter", "s2");

		Thread.sleep(1500);
		driver.quit();

	}
}
