package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static org.example.Main.takeScreenshot;

public class ScenarioThree {
//Group-4
	private static WebDriver driver;

	@Test
	public void launch() {
		// Set ChromeOptions to configure the browser
		ChromeOptions options = new ChromeOptions();
		Map<String, Object> prefs = new HashMap<>();
		prefs.put("download.default_directory", "/Users/jayakishnani/Desktop");

		// Instantiate WebDriver with ChromeOptions
		driver = new ChromeDriver(options);

		try {

			driver.get("https://service.northeastern.edu/tech?id=classrooms");
			driver.manage().window().maximize();

			String originalWindowHandle = driver.getWindowHandle();

			// takeScreenshot("classroom_link_before");

			// driver.manage().timeouts().implicitlyWait(2000, TimeUnit.SECONDS);
			Thread.sleep(5000);
			takeScreenshot(driver, "BeforeClickClassroom", "s3");
			// Locate and click on the Classroom link
			WebElement classroomLink = driver.findElement(By.xpath(
					"//*[@id=\"x77ea03d9972dd1d8beddb4221153afa6\"]/div/div[2]/span/div/div/div[1]/div/div/div/a"));
			classroomLink.click();
			// Capture a screenshot after clicking the Classroom link
			Thread.sleep(5000);
			takeScreenshot(driver, "AfterClickClassroom", "s3");

			System.out.println("SS taken");

			Thread.sleep(500);
			takeScreenshot(driver, "nuflex_link_before", "s3");
			// Locate and click on the NuFlex link
			WebElement nuflexLink = driver.findElement(By.xpath(
					"//*[@id=\"x51d2fa949721d518beddb4221153af23\"]/div/div[2]/span/table[1]/tbody/tr[1]/td[2]/a"));
			nuflexLink.click();

			Thread.sleep(5000);

			// Switch to the new window that opens after clicking the NuFlex link
			Set<String> windowHandles = driver.getWindowHandles();

			for (String windowHandle : windowHandles) {
				if (!windowHandle.contains(originalWindowHandle)) {

					driver.switchTo().window(windowHandle);
					if (driver.getCurrentUrl().equals(
							"https://nuflex.northeastern.edu/wp-content/uploads/2020/11/Hybrid_Nuflex_Classroom.pdf")) {
						break;
					}
				}
			}
			// Capture a screenshot after clicking the NuFlex link
			Thread.sleep(5000);
			takeScreenshot(driver, "nuflex_link_after", "s3");

			Robot robot = new Robot();

			// Use Robot to simulate mouse and keyboard actions
			robot.mousePress(InputEvent.BUTTON1_MASK); // Press the left mouse button
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
			robot.keyPress(KeyEvent.VK_META);
			robot.delay(200);
			robot.keyPress(KeyEvent.VK_S);
			robot.keyRelease(KeyEvent.VK_META);

			Thread.sleep(5000);

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);
			// Quit the WebDriver
			driver.quit();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			// Handle exceptions and print the stack trace
			e.printStackTrace();
		}
	}
}
