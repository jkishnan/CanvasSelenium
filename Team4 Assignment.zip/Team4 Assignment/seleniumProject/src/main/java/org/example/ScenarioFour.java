package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.io.IOException;
import java.time.Duration;

import static org.example.Main.takeScreenshot;
import static org.openqa.selenium.support.ui.ExpectedConditions.numberOfWindowsToBe;

public class ScenarioFour {
	WebDriver driver;
//Group-4
	@Test
	public void launch() throws InterruptedException, IOException {
		
		// Initialize WebDriver and WebDriverWait
		driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5000));

		// Open the specified URL and maximize the window
		driver.get("https://onesearch.library.northeastern.edu/discovery/search?vid=01NEU_INST:NU&lang=en");
		driver.manage().window().maximize();
		
		// Click on the 'Digital' link in the main menu
        Thread.sleep(500);
		takeScreenshot(driver, "before_open_digital", "s4");
		WebElement digital = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"mainMenu\"]/div[5]/a/span")));
		digital.click();
		
		// Switch to the new window that opened after clicking 'Digital'
		wait.until(numberOfWindowsToBe(2));
		String originalWindow = driver.getWindowHandle();
		for (String windowHandle : driver.getWindowHandles()) {
			if (!originalWindow.contentEquals(windowHandle)) {
				driver.switchTo().window(windowHandle);
				break;
			}
		}
		
		// Take a screenshot after opening the 'Digital' page
		Thread.sleep(500);
		takeScreenshot(driver, "after_open_digital", "s4");
		
		// Click on the 'Dataset' link on the 'Digital' page
		WebElement dataset = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("//*[@id=\"main-content\"]/div[1]/section/div[1]/a[5]")));
		dataset.click();
		
		// Take a screenshot before opening the 'Zipfile'
		Thread.sleep(500);
		takeScreenshot(driver, "before_open_zipfile", "s4");
		
		
		// Click on the 'Zipfile' link on the 'Dataset' page
		WebElement zipfile = wait.until(ExpectedConditions.elementToBeClickable(
				By.xpath("//*[@id=\"main-content\"]/div[2]/main/section/ul/article[1]/div/div/div/div/div[1]/a[1]")));
		zipfile.click();
		
		// Take a screenshot after opening the 'Zipfile'
		Thread.sleep(500);
		takeScreenshot(driver, "after_open_zipfile", "s4");
		
		// Wait for a brief period and then quit the WebDriver
		Thread.sleep(2000);
		driver.quit();

	}
}
