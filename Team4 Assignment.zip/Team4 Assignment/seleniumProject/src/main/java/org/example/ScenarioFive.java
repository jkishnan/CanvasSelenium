package org.example;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import static org.example.Main.takeScreenshot;
import static org.openqa.selenium.support.ui.ExpectedConditions.numberOfWindowsToBe;

public class ScenarioFive {
	WebDriver driver;
//Group-4
	@Test
	public void launch() throws IOException, InterruptedException {
		// Initialize WebDriver
		driver = new ChromeDriver();
		driver.get("https://northeastern.sharepoint.com/sites/studenthub/SitePages/Student-Resources.aspx#/resources");
		driver.manage().window().maximize();

		// Read data from Excel
		String excelFilePath = "/Users/jayakishnani/Desktop/data.xlsx";
		FileInputStream inputStream = new FileInputStream(excelFilePath);
		Workbook workbook = new XSSFWorkbook(inputStream);
		Sheet sheet = workbook.getSheet("Sheet1");
		String usernameEmail = sheet.getRow(0).getCell(0).getStringCellValue();
		String username = sheet.getRow(1).getCell(0).getStringCellValue();
		String password = sheet.getRow(0).getCell(1).getStringCellValue();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5000));
		// Enter user email and click 'Next'
		WebElement userEmail = driver.findElement(By.id("i0116"));
		userEmail.sendKeys(usernameEmail);
		Thread.sleep(2000);
		// click next
		WebElement next = wait.until(ExpectedConditions.elementToBeClickable(By.id("idSIButton9")));

		next.click();
		Thread.sleep(1000);
        //Enter password and sign in
		WebElement userPassword = driver.findElement(By.id("i0118"));
		userPassword.sendKeys(password);

		// maybe need to wait untill the page is fully loaded

		WebElement SignIn = wait.until(ExpectedConditions.elementToBeClickable(By.id("idSIButton9")));

		SignIn.click();
		//Click on yes this is my device
				WebElement yesThisIsMyDevice=wait.until(ExpectedConditions.elementToBeClickable(By.id("trust-browser-button")));
				yesThisIsMyDevice.click();
		// Handle DUO authentication
		WebElement doNotShowAgain = wait.until(ExpectedConditions.elementToBeClickable(By.name("DontShowAgain")));
		doNotShowAgain.click();
		WebElement noButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("idBtn_Back")));
		noButton.click();
		Thread.sleep(2000);
		takeScreenshot(driver, "before_click_academic", "s5");
		// Navigate to Academic section
		WebElement academics = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
				"//*[@id=\"vpc_WebPart.ResourcesWebPartWebPart.external.7b3083e7-1956-4f64-968b-920d938ba636\"]/div/div[1]/div[2]/div/div[1]/div/div/img\n")));
		academics.click();

		Thread.sleep(1500);
		takeScreenshot(driver, "after_click_academic", "s5");
		// Open Academic Calendar

		WebElement academicCalendar = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
				"//*[@id=\"vpc_WebPart.ResourcesWebPartWebPart.external.7b3083e7-1956-4f64-968b-920d938ba636\"]/div/div[2]/div/div/div[1]/div/div[1]/div/div/a\n")));
		Thread.sleep(500);
		takeScreenshot(driver, "before_click_calendar", "s5");
		academicCalendar.click();

		// Switch to the new window
		wait.until(numberOfWindowsToBe(2));
		String originalWindow = driver.getWindowHandle();
		for (String windowHandle : driver.getWindowHandles()) {
			if (!originalWindow.contentEquals(windowHandle)) {
				driver.switchTo().window(windowHandle);
				break;
			}
		}

		Thread.sleep(500);
		takeScreenshot(driver, "after_click_calendar", "s5");
		
		// Click on the academic calendar in the new tab
		WebElement newTab = wait.until(
				ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"tax-academic-calendars\"]/div/a[1]/div")));
		newTab.click();

		// Scroll down in the iframe
		Thread.sleep(500);
		takeScreenshot(driver, "before_scroll_down", "s5");
		Thread.sleep(2000);
		WebElement iframe = driver.findElement(By.id("trumba.spud.6.iframe"));

		new Actions(driver).scrollToElement(iframe).perform();
		Thread.sleep(2000);
		// Uncheck a checkbox in the iframe
		takeScreenshot(driver, "After_scroll_down", "s5");

		takeScreenshot(driver, "before_uncheck_box", "s5");
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("trumba.spud.6.iframe")));
		WebElement checkBox = driver.findElement(By.xpath("//*[@id=\"mixItem0\"]"));
		if (checkBox.isSelected()) {
			// If it's selected, uncheck it
			checkBox.click();
		}
		// Scroll to the bottom of the page
		// river.switchTo().defaultContent();
		Thread.sleep(500);
		takeScreenshot(driver, "after_uncheck_box", "s5");
		Thread.sleep(2000);

		Thread.sleep(500);
		takeScreenshot(driver, "before_go_to_bottom", "s5");
		driver.switchTo().defaultContent();
		WebElement iframe2 = driver.findElement(By.id("trumba.spud.2.iframe"));
		WebElement bottom = driver.findElement(By.xpath("//*[@id=\"nu-global-footer\"]/footer/div[1]/div[2]/a[3]"));

		new Actions(driver).scrollToElement(bottom).perform();
		driver.switchTo().frame(iframe2);
		Thread.sleep(500);
		takeScreenshot(driver, "After_go_to_bottom", "s5");
		Thread.sleep(2000);
		// Verify an element is displayed at the bottom
		WebElement table = driver.findElement(By.xpath("//*[@id=\"ctl04_ctl90_ctl00_actionsWrap\"]/table"));
		WebElement addToMy = table.findElement(By.id("ctl04_ctl90_ctl00_buttonAtmc"));

		boolean checkpoint = addToMy.isDisplayed();
		Assert.assertTrue(checkpoint);
		Thread.sleep(2000);
		// Quit the driver
		driver.quit();
	}
}
