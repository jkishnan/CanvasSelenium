package org.example;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.Duration;

public class Main {

//Group-4
    public static void main(String[] args) throws IOException, InterruptedException, AWTException {
    	// Your main method logic goes here
    }
    /**
     * Takes a screenshot of the current WebDriver instance and saves it to a specified file.
     *
     * @param driver   The WebDriver instance.
     * @param fileName The base name of the screenshot file.
     * @param scenario A label indicating the context or scenario for the screenshot.
     * @throws IOException If an I/O error occurs during screenshot capture or file copying.
     */
    public static void takeScreenshot(WebDriver driver, String fileName, String scenario) throws IOException {
        // Convert WebDriver object to TakesScreenshot
        TakesScreenshot screenshot = (TakesScreenshot) driver;

     // Capture the screenshot as a file
        File sourceFile = screenshot.getScreenshotAs(OutputType.FILE);

        // Specify the destination file
        File destinationFile = new File("/Users/jayakishnani/Desktop/seleniumProject/ScreenShot" +"/" +scenario + "/" + fileName + "_" + System.currentTimeMillis() + ".png");

        // Copy the screenshot file to the specified destination
        Files.copy(sourceFile.toPath(), destinationFile.toPath());
    }

    public static void waitForPageLoad(WebDriver driver) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3000)); // Adjust the timeout as needed

        // Wait for the presence of an element on the page that indicates it has loaded
        wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));
    }
}
