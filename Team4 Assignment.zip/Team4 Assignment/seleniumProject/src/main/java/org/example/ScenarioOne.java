package org.example;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;

import static org.example.Main.takeScreenshot;
import static org.example.Main.waitForPageLoad;
import static org.openqa.selenium.support.ui.ExpectedConditions.numberOfWindowsToBe;

public class ScenarioOne {
	WebDriver driver;
//Group-4
	@Test
	public void launch() throws IOException, InterruptedException, AWTException {
		// Set up Chrome options for a customized browser session
		ChromeOptions options = new ChromeOptions();
		HashMap<String, Object> chromeOptionsMap = new HashMap<String, Object>();
		chromeOptionsMap.put("plugins.plugins_disabled", new String[] { "Chrome PDF Viewer" });
		chromeOptionsMap.put("plugins.always_open_pdf_externally", true);
		chromeOptionsMap.put("download.default_directory", "/Users/jayakishnani/Desktop");
		chromeOptionsMap.put("download.prompt_for_download", false);
		// options.addArguments("--disable-print-preview");
		options.addArguments("download.default_directory=/Users/jayakishnani/Desktop");
		options.setExperimentalOption("prefs", chromeOptionsMap);
		// Initialize ChromeDriver with custom options
		driver = new ChromeDriver(options);
		driver.get("https://me.northeastern.edu/");
		driver.manage().window().maximize();
		// Locate the email input window
		WebElement userEmail = driver.findElement(By.id("i0116"));
		// Wait for page load and capture a screenshot
		waitForPageLoad(driver);
		Thread.sleep(500);
		takeScreenshot(driver, "loginBefore", "s1");

		// Read data from Excel file
		String excelFilePath = "/Users/jayakishnani/Desktop/data.xlsx";
		FileInputStream inputStream = new FileInputStream(excelFilePath);
		Workbook workbook = new XSSFWorkbook(inputStream);
		Sheet sheet = workbook.getSheet("Sheet1");
		String usernameEmail = sheet.getRow(0).getCell(0).getStringCellValue();
		String username = sheet.getRow(1).getCell(0).getStringCellValue();
		String password = sheet.getRow(0).getCell(1).getStringCellValue();

		// Enter email and navigate to the next step
		userEmail.sendKeys(usernameEmail);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5000));

		// click next
		WebElement next = wait.until(ExpectedConditions.elementToBeClickable(By.id("idSIButton9")));

		next.click();
		Thread.sleep(1000);
		// Fill in password and sign in
		WebElement userPassword = driver.findElement(By.id("i0118"));
		userPassword.sendKeys(password);
		
	

		// maybe need to wait untill the page is fully loaded

		WebElement SignIn = wait.until(ExpectedConditions.elementToBeClickable(By.id("idSIButton9")));

		SignIn.click();
		//Click on yes this is my device
		WebElement yesThisIsMyDevice=wait.until(ExpectedConditions.elementToBeClickable(By.id("trust-browser-button")));
		yesThisIsMyDevice.click();

		// Perform manual DUO finish
		WebElement doNotShowAgain = wait.until(ExpectedConditions.elementToBeClickable(By.name("DontShowAgain")));
		doNotShowAgain.click();
		WebElement noButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("idBtn_Back")));
		noButton.click();

		// Click "Let's Go"
		Thread.sleep(2500);
		WebElement letsGo = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("/html/body/div[2]/div/div/div/div[2]/div[2]/button[2]")));
		waitForPageLoad(driver);
		takeScreenshot(driver, "loginAfter", "s1");
		letsGo.click();
		// Navigate to "Academics"
		WebElement resource = wait.until(ExpectedConditions.elementToBeClickable(
				By.xpath("//*[@id=\"spSiteHeader\"]/div/div[2]/div[1]/div[3]/div/div/div/div/span[4]/a/span")));
		resource.click();
		// Click on "Transcript"
		Thread.sleep(500);
		takeScreenshot(driver, "academicsBefore", "s1");
		WebElement academics = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
				"//*[@id=\"vpc_WebPart.ResourcesWebPartWebPart.external.7b3083e7-1956-4f64-968b-920d938ba636\"]/div/div[1]/div[2]/div/div[1]/div/div/img\n")));
		academics.click();
		// click
		Thread.sleep(500);
		takeScreenshot(driver, "academicsAfter", "s1");
		WebElement transcript = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
				"//*[@id=\"vpc_WebPart.ResourcesWebPartWebPart.external.7b3083e7-1956-4f64-968b-920d938ba636\"]/div/div[2]/div/div/div[1]/div/div[21]/div/div/a\n")));
		transcript.click();

		// Switch to the new window for transcript search

		wait.until(numberOfWindowsToBe(2));
		String originalWindow = driver.getWindowHandle();
		for (String windowHandle : driver.getWindowHandles()) {
			if (!originalWindow.contentEquals(windowHandle)) {
				driver.switchTo().window(windowHandle);
				break;
			}
		}
		Thread.sleep(500);
		takeScreenshot(driver, "transcriptSearchBefore", "s1");
		WebElement userName2 = wait.until(ExpectedConditions.elementToBeClickable(By.id("username")));
		userName2.sendKeys(username);
		WebElement passWord2 = wait.until(ExpectedConditions.elementToBeClickable(By.name("j_password")));
		// data driven
		passWord2.sendKeys(password);
		WebElement submit = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("/html/body/section/div/div[2]/div/form/div[3]/button\n")));
		submit.click();
		
		// Select "Graduate" from the dropdown
		Select drpCountry = new Select(wait.until(ExpectedConditions.elementToBeClickable(By.id("levl_id"))));
		drpCountry.selectByVisibleText("Graduate");

		WebElement findTranscript = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[3]/form/input")));
		findTranscript.click();
		Thread.sleep(500);
		takeScreenshot(driver, "transcriptSearchBefore", "s1");
		// Download the PDF using Robot class

		Robot robot = new Robot();
		// have to manually close , since it is out of selenium scope
		// ((ChromeDriver) driver).executeScript("window.print();");

		// Click on the download link
		robot.mousePress(InputEvent.BUTTON1_MASK); // Press the left mouse button
		robot.mouseRelease(InputEvent.BUTTON1_MASK);
		robot.keyPress(KeyEvent.VK_META);
		robot.delay(200);
		robot.keyPress(KeyEvent.VK_P);

		robot.keyRelease(KeyEvent.VK_META);
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(5000);

		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);

		 driver.quit();

	}
}
